# Bug Fixes

- Fix grants and scopes for the `concourse` UAA Client, so that it
  can be used from Genesis CI/CD pipelines.

# Release Engineering

We're trying out a new Concourse CI/CD pipeline for automating the
testing, vetting, and releasing of Genesis Kits, and this kit is
our second trial run.
